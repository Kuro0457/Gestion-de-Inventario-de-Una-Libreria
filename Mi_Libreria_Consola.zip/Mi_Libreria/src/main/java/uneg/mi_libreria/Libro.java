package uneg.mi_libreria;

public class Libro {

    private String titulo, autor;
    private int precio, cantidad, añadir, ventas, money;

    public Libro(String titulo, String autor, int precio,int cantidad) {
        this.titulo = titulo;
        this.autor = autor;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
        if(cantidad>0){
        this.cantidad = cantidad;
        }else{
            System.out.println("Por favor ingrese un entero positivo!");
    }}
    
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getPrecio() {
        return precio;
        }

    public void setPrecio(int precio) {
        if(precio>0){
        this.precio = precio;
        }else{
            System.out.println("Por favor ingrese un entero positivo!");
        }
    }

    public int getVentas() {
        return ventas;
    }

    public void setVentas(int ventas) {
        this.ventas = ventas;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }
    
    
    
    
    
    int actualizarPrecio(int cantidad, int añadir){
    cantidad = cantidad + añadir;
    return cantidad;
    }
    
    int libroVendido(int cantidad, int ventas){
        cantidad = cantidad - ventas;
        return cantidad;
    }
    
    int caldularVentas(int ventas, int precio){
        money = precio * ventas;
        
        return money;
    }
    
    int positivo(int num){
        num = num*-1;
        return num;
    }

    @Override
    public String toString() {
        return "Titulo: " + titulo + " \nAutor: " + autor + "\nPrecio: " + precio + "\nCantidad: " + cantidad;
    }
    
    
    
}
