package uneg.mi_libreria;

import java.util.ArrayList;
import java.util.Scanner;

//Gestión de Inventarios: 
//Librería

public class Mi_Libreria {
    
    public static void main(String[] args) {
        
        ArrayList<Libro> catalogo = new ArrayList<>();
        Scanner teclado = new Scanner(System.in);
        
        int precio, eliminar, cantidad = 0, money =0;
        String opcion="", titulo="", autor="";
        
        
        do{
            System.out.println("\n================================");
            System.out.println("   .::MENU::.");
            System.out.println("================================");
            System.out.println("DINERO: "+ money+"$");
            System.out.println("================================");
            
            System.out.println("[1] Mostrar Catalogo");
            System.out.println("[2] Agregar un Libro");
            System.out.println("[3] Eliminar un Libro");
            System.out.println("[4] Modificar un Libro");
            System.out.println("[5] Vender Libro");
            System.out.println("[6] Salir de el Programa");

            System.out.print("opcion: ");
            opcion = teclado.nextLine();
            
            switch(opcion){

                case "1" ->{
                    if(catalogo.isEmpty()){
                        System.out.println("\nEl catalogo esta vacio\n");
                    }else{
                        for(int i=0; i<catalogo.size(); i++){
                            
                            Libro miLibro = catalogo.get(i);
                            System.out.println("---------------------------------");
                            System.out.println("Libro "+(i+1));
                            System.out.println(miLibro);
                            System.out.println("---------------------------------");
                           
                        }
                    }
                }

                case "2" ->{
                    System.out.print("Introduzca el titulo de el libro: ");
                    titulo = teclado.nextLine();
                    
                    System.out.print("Introduzca el Autor de el Libro: ");
                    autor = teclado.nextLine();
                    
                    System.out.print("Introduce la Cantidad de libros: ");
                    cantidad = teclado.nextInt();
                    teclado.nextLine();
                    if(cantidad <0){
                        
                        cantidad *=-1;
                    }
                    
                    
                    System.out.print("Indroduce el Precio de el Libro: ");
                    
                    if(teclado.hasNextInt()){
                        precio = teclado.nextInt();
                        if(precio <0){
                            precio *=-1;
                        }

                        Libro libroNuevo = new Libro(titulo,autor, precio, cantidad);

                        catalogo.add(libroNuevo);
                        System.out.println("\nEl libro '"+ titulo + "' se ha guardado con exito!\n");
                    }else{
                        System.out.println("\nError: Debes ingresar un numero entero valido.\n"); 
                    }
                    teclado.nextLine();
                    
                    
                }
                case "3" ->{
                    System.out.print("\nIngrese el numero de el Libro que desea Eliminar de el Catalogo: ");
                    eliminar = teclado.nextInt();
                    teclado.nextLine();
                    eliminar -=1;
                    
                    if(eliminar<catalogo.size()){
                    catalogo.remove(eliminar);
                    System.out.println("\nLibro Eliminado con Exito!\n");
                    }else{
                        System.out.println("\nIntroduce un Dato Valido!\n");
                    }
                    
                    
                }

                case "4" ->{
                    int posicion, op;
                    
                    System.out.print("\nIngrese el Indice de el Catalogo de el Libro que desea modificar: ");
                    posicion = teclado.nextInt();
                    teclado.nextLine();
                    posicion -=1;
                    
                    if(posicion < catalogo.size()){
                    
                    
                    Libro miLibro = catalogo.get(posicion);
                    
                    System.out.println("\nMENU MODIFICAR LIBRO");
                    System.out.println("[1] Modificar Titulo");
                    System.out.println("[2] Modificar Autor");
                    System.out.println("[3] Modificar Precio");
                    System.out.println("[4] Modificar Cantidad en Stock");
                    System.out.println("[5] Añadir Cantidad en Stock");
                    System.out.println("[6] Modificar todo el Libro");
                    System.out.print("Opcion: ");
                    
                    op = teclado.nextInt();
                    teclado.nextLine();
                    
                    switch(op){
                        case 1->{
                            System.out.print("\nIngrese el nuevo Titulo: ");
                            titulo = teclado.nextLine();
                            miLibro.setTitulo(titulo);
                            
                            System.out.println("\nEl Titulo ha sido actualizado a: '" + miLibro.getTitulo() + "'\n");
                        }
                        case 2->{
                            System.out.print("\nIngrese el Nuevo Autor: ");
                            autor = teclado.nextLine();
                            
                            miLibro.setAutor(autor);
                            
                            System.out.println("\nEl Autor ha sido actualizado a: '"+ miLibro.getAutor()+"'\n");
                        }
                        case 3->{
                            System.out.print("\nIngrese el nuevo Precio: ");
                            precio = teclado.nextInt();
                            teclado.nextLine();
                            
                            if(precio<0){
                                precio*=-1;
                            }
                            
                            miLibro.setPrecio(precio);
                            
                            System.out.println("\nEl precio ha sido actualizado a: '"+ miLibro.getPrecio()+"'\n");
                            
                            
                            
                        }
                        case 4->{
                            System.out.print("\nIngresa la nueva cantidad en Stock: ");
                            cantidad = teclado.nextInt();
                            teclado.nextLine();
                            
                            if(cantidad<0){
                                cantidad*= -1;
                            }
                            
                            miLibro.setCantidad(cantidad);
                            
                            System.out.println("\nLa nueva cantidad ha sido actualizada a: '"+ miLibro.getCantidad()+"'\n");
                        }
                        case 5->{
                            int añadir;
                            
                            System.out.println("\nAñadir Libros al Stock de el libro '"+ miLibro.getTitulo()+"'\n");
                            System.out.print("\nIngresa la Candidad que desea añadir: ");
                            añadir = teclado.nextInt();
                            teclado.nextLine();
                            
                            if(añadir<0){
                                añadir*=-1;
                            }
                            
                            cantidad = miLibro.actualizarPrecio(cantidad, añadir);
                            miLibro.setCantidad(cantidad);
                            
                            
                            System.out.println("\nLa Candiad de Libros en el Stock ha sido actualizada a: '"+ miLibro.getCantidad()+"'\n");
                        }
                        case 6->{
                            System.out.println("\nModificar Todos los Libros\n");
                            System.out.print("Ingrese el nuevo Titulo: ");
                            titulo = teclado.nextLine();

                            System.out.print("Ingrese el Nuevo Autor: ");
                            autor = teclado.nextLine();

                            System.out.print("Ingrese el nuevo Precio: ");
                            precio = teclado.nextInt();
                            teclado.nextLine();
                            
                            if(precio<0){
                                precio*=-1;
                            }
                            
                            System.out.println("\nIngrese la nueva cantidad en Stock");
                            cantidad = teclado.nextInt();
                            
                            if(cantidad<0){
                                cantidad*=-1;
                            }

                            
                            miLibro.setTitulo(titulo);
                            miLibro.setAutor(autor);
                            miLibro.setPrecio(precio);
                            miLibro.setCantidad(cantidad);

                            System.out.println("\nLibro Modificado con Exito!\n");
                        }
                        default ->{
                            System.out.println("\nIngrese un Dato Valido!\n");
                        }
                    }
                    
                    }else{
                        System.out.println("\nIngrese un Dato Valido!\n");
                    }
                }
                case "5" ->{
                    int posicion,ventas;
                    
                    
                    System.out.print("Ingrese el Indice de el Libro que desea vender: ");
                    posicion = teclado.nextInt();
                    teclado.nextLine();
                    posicion -=1;
                    
                    
                    if(posicion<catalogo.size()){
                        Libro miLibro = catalogo.get(posicion);
                        
                        System.out.println("HA SELECCIONADO EL LIBRO '"+ miLibro.getTitulo()+"'");
                        System.out.print("\nPorFavor Ingrese la cantidad de Libros que desea vender: ");
                        ventas = teclado.nextInt();
                        teclado.nextLine();
                        
                        if(ventas < miLibro.getCantidad()){
                            
                        cantidad = miLibro.libroVendido(cantidad, ventas);
                        miLibro.setCantidad(cantidad);
                        miLibro.setVentas(ventas);
                        
                        precio = miLibro.getPrecio();
                        
                        money = miLibro.caldularVentas(ventas, precio);
                        miLibro.setMoney(money);
                        
                        System.out.println("\nHas Vendido: '" + miLibro.getVentas()+"' Libros\n");
                        
                        }else{
                            System.out.println("\nIngrese una Cantidad de Libros que halla en el Stock!\n");
                        }
                        
                        
                    }
                }
                case "6"->{
                    System.out.println("\nSaliendo de el Programa\n");
                }
                default ->{
                    System.out.println("\nIngrese un dato Valido!\n");

                }
            }
                
        }while(!opcion.equals("6"));
        
        }
    }
